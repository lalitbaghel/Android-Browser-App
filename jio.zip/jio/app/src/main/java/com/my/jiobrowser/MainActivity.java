package com.my.jiobrowser;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;



public class MainActivity extends Activity {

	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private WebView webview2;
	private EditText edittext1;
	private ImageView imageview1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	private ImageView imageview5;
	private ImageView imageview6;
	private ImageView imageview7;
	private ImageView imageview8;

	private double i = 0;


	private Intent splash = new Intent();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		webview2 = (WebView) findViewById(R.id.webview2);
		webview2.getSettings().setJavaScriptEnabled(true);
		webview2.getSettings().setSupportZoom(true);
		webview2.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _view,final String _url, Bitmap _favicon) {

				super.onPageStarted(_view, _url, _favicon);
			}
			@Override
			public void onPageFinished(WebView _view,final String _url) {

				super.onPageFinished(_view, _url);
			}
		});
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		imageview8 = (ImageView) findViewById(R.id.imageview8);



		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.loadUrl("https://".concat(edittext1.getText().toString()));
			}
		});
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.loadUrl("https://www.jio.com");
			}
		});
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.loadUrl("https://www.google.co.in");
			}
		});
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.loadUrl("https://m.youtube.com");
			}
		});
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (webview2.canGoBack()) {
					webview2.goBack();
				}
			}
		});
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (webview2.canGoForward()) {
					webview2.goForward();
				}
			}
		});
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.zoomIn();
			}
		});
		imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				webview2.zoomOut();
			}
		});

	}

	private void  initializeLogic() {
		i = 01;
		webview2.loadUrl("https://grin.co/live-youtube-subscriber-count/MTADVICE-");
		splash.setClass(getApplicationContext(), SplashActivity.class);
		startActivity(splash);
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
